import Header from "./components/Header";
import Song from "./components/Song";

/*
Component - Arrow Function
JS ES6 (2015)
*/
const App = ()=><div>
  <Header/>
  <Song/>
</div>
export default App;