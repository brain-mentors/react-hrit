import { useEffect, useState } from "react";

const Song = ()=>{
    const [songs, setSongs] = useState([]);
    useEffect(()=>{
        
        // Component Mount
        makeApiCall(); 
    },[]);
    
    const makeApiCall = async ()=>{
        // bring response from URL (Web API)
        const URL = 'https://itunes.apple.com/'+
        'search?term=daler+mehndi&limit=25';
       const response =  await fetch(URL); // time taking call (Async)
       const data = await response.json(); 
       setSongs(data.results);
       console.log("Data from itunes ", data);
    }
    return (<div>
        {songs.map(currentSong=><div>
            <img src = {currentSong.artworkUrl100} />
            <p>{currentSong.trackName}</p>
            <audio controls src={currentSong.previewUrl}>
                <source type="audio/mp3"/>
            </audio>
        </div>)}
    </div>)
}
export default Song;